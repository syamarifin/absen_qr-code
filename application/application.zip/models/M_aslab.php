<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_aslab extends CI_Model {

    public function __cnstruct(){
        parent::__cnstruct();
        $this->labels = $this->_atributeLabels();
        //memuat library database
        $this->load->database();
    }

    function cek_nim($table,$where){      
        return $this->db->get_where($table,$where);
    }

    function tampil_dataKabid($search){
        $sql="SELECT * FROM tbaslab where isActive='Y' and jabatan='ASLAB' $search";
        $hasil=$this->db->query($sql);
        return $hasil;
    }

    function select_data($id){
        $hasil=$this->db->query("SELECT * FROM tbaslab where idAslab='$id'");
        return $hasil;
    }

    function input_data_aslab($data,$table){
        $this->db->insert($table,$data);
    }

    function update_data_aslab($where,$data,$table){
        $this->db->where($where);
        $this->db->update($table,$data);
    }

    function hapus_data_aslab($where,$data,$table){
        $this->db->where($where);
        $this->db->update($table,$data);
    }

    public function cekkodeAslab()
    {
        $query = $this->db->query("SELECT MAX(idAslab) as kodeAslab from tbaslab");
        $hasil = $query->row();
        return $hasil->kodeAslab;
    }
    
}

?>